isi semua file js
