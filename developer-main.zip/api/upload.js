const express = require('express');
const { createClient } = require('@supabase/supabase-js');

const router = express.Router();

// Supabase Configuration
const SUPABASE_URL = process.env.SUPABASE_URL || "https://hxxvyjzpcabwuvvbgftu.supabase.co";
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY;
const STORAGE_BUCKET = "foto-absensi";

// ImgBB fallback key
const IMGBB_KEY = process.env.IMGBB_KEY;

let supabaseClient = null;
if (SUPABASE_URL && SUPABASE_ANON_KEY) {
  supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}

function getFileExtension(filename) {
  return filename.split('.').pop().toLowerCase();
}

async function uploadToSupabase(fileBuffer, originalName, folder = 'uploads', userId = null) {
  if (!supabaseClient) {
    throw new Error('Supabase not configured');
  }
  
  const ext = getFileExtension(originalName);
  const timestamp = Date.now();
  const randomStr = Math.random().toString(36).substring(2, 8);
  
  let fullPath;
  if (userId) {
    fullPath = `${folder}/${userId}/${timestamp}_${randomStr}.${ext}`;
  } else {
    fullPath = `${folder}/${timestamp}_${randomStr}.${ext}`;
  }
  
  const { data, error } = await supabaseClient.storage
    .from(STORAGE_BUCKET)
    .upload(fullPath, fileBuffer, {
      cacheControl: '3600',
      upsert: false,
      contentType: `image/${ext}`
    });
  
  if (error) throw error;
  
  const { data: urlData } = supabaseClient.storage
    .from(STORAGE_BUCKET)
    .getPublicUrl(fullPath);
  
  return { url: urlData.publicUrl, path: fullPath };
}

async function uploadToImgBB(fileBuffer, filename) {
  if (!IMGBB_KEY) {
    throw new Error('ImgBB key not configured');
  }
  
  const base64 = fileBuffer.toString('base64');
  const formData = new FormData();
  formData.append('image', base64);
  formData.append('name', filename);
  
  const response = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_KEY}`, {
    method: 'POST',
    body: formData
  });
  
  const data = await response.json();
  if (!data.success) {
    throw new Error('ImgBB upload failed');
  }
  
  return data.data.image.url;
}

router.post('/upload', async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  
  try {
    // Parse multipart form data
    const formData = await req.formData();
    const file = formData.get('file');
    const folder = formData.get('folder') || 'uploads';
    const userId = formData.get('userId') || null;
    
    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      return res.status(400).json({ error: 'File size exceeds 5MB limit' });
    }
    
    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      return res.status(400).json({ error: 'Invalid file type. Only images are allowed.' });
    }
    
    const fileBuffer = Buffer.from(await file.arrayBuffer());
    let url, path = null, isFallback = false;
    
    try {
      // Try Supabase first
      const result = await uploadToSupabase(fileBuffer, file.name, folder, userId);
      url = result.url;
      path = result.path;
    } catch (supabaseError) {
      console.warn('Supabase upload failed, using ImgBB fallback:', supabaseError.message);
      isFallback = true;
      url = await uploadToImgBB(fileBuffer, file.name);
    }
    
    res.json({ 
      success: true, 
      url: url,
      path: path,
      isFallback: isFallback
    });
    
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

module.exports = router;