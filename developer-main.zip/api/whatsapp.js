const express = require('express');

const router = express.Router();

const FONNTE_API_KEY = process.env.FONNTE_API_KEY;

router.post('/whatsapp/send', async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  
  if (!FONNTE_API_KEY) {
    return res.status(503).json({ 
      success: false, 
      error: 'WhatsApp API not configured' 
    });
  }
  
  try {
    const { phoneNumber, message, title } = req.body;
    
    if (!phoneNumber || !message) {
      return res.status(400).json({ error: 'Phone number and message are required' });
    }
    
    // Format phone number
    let formattedNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (formattedNumber.startsWith('0')) formattedNumber = '62' + formattedNumber.substring(1);
    if (!formattedNumber.startsWith('62')) formattedNumber = '62' + formattedNumber;
    
    const fullMessage = `*📢 SISTEM ABSENSI SEKOLAH*\n\n*${title || 'Notifikasi'}*\n\n${message}\n\n---\n📱 Sistem Absensi IoT - Real-time`;
    
    const response = await fetch('https://api.fonnte.com/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': FONNTE_API_KEY
      },
      body: JSON.stringify({
        target: formattedNumber,
        message: fullMessage,
        countryCode: '62'
      })
    });
    
    const result = await response.json();
    
    if (result.status === true) {
      res.json({ success: true, message: 'WhatsApp sent successfully' });
    } else {
      throw new Error(result.reason || 'Failed to send WhatsApp');
    }
    
  } catch (error) {
    console.error('WhatsApp send error:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

module.exports = router;